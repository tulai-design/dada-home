# Tulai Sync

面向本地优先应用的可选自建同步服务，由 `tulai-design` 独立维护。首期服务于[搭搭](https://github.com/tulai-design/dada-home)和[默默](https://github.com/tulai-design/momoki)，保留两个产品完整的纯本地使用能力。

**当前已实现记录、对象与设备同步服务**：应用/空间隔离、SQLite 持久化、原子版本检查、幂等提交、可恢复冲突候选、固定水位增量分页；大正文按块上传/续传，完整校验后发布引用；设备可限时配对、立即撤销。两个产品尚未正式接入。

通用SDK及客户端加密基础已实现并完成本地打包/浏览器互通验收；搭搭/默默产品适配和Docker部署仍待后续。`/v1/capabilities`报告服务能力与传输预算，encryption=false表示服务不执行或强制加密；SDK可在发送前加密opaque内容。本版用于本机开发与合成数据验证，不作为已经完成生产部署验收的版本。

## 本地启动

开发验证环境为 **Node 24.11.0**（见`.nvmrc`），服务运行模块没有npm依赖；新客户端SDK使用精确@noble/hashes 2.4.0做增量SHA256。运行服务无需安装客户端依赖，开发/检查SDK请先用兼容pnpm安装。该版本的`node:sqlite`仍有实验性提示；当前单进程单连接使用DELETE journal与EXTRA同步，不启用WAL。生产运行时会在部署阶段另行核对。

先生成独立随机访问令牌：

```sh
node --input-type=module -e "import {randomBytes} from 'node:crypto'; console.log(randomBytes(32).toString('base64url'))"
```

在已忽略的`secrets/devices.json`保存静态引导管理员配置（替换令牌占位内容，文件权限建议600）：

```json
{
  "devices": [
    {
      "id": "laptop",
      "token": "替换为上一步生成的随机令牌",
      "scopes": [{"appId": "dada", "spaceId": "personal"}]
    }
  ]
}
```

然后启动：

```sh
TULAI_SYNC_AUTH_FILE=./secrets/devices.json node apps/server/main.mjs
```

默认监听`127.0.0.1:8787`、数据库`./data/sync.sqlite`。可显式设置`TULAI_SYNC_HOST`、`TULAI_SYNC_PORT`、`TULAI_SYNC_DB`；缺失或无效设备配置会拒绝启动。这些静态管理令牌在启动读取，修改/撤销须重启；通过配对创建的日常设备可立即远程撤销。访问令牌不是客户端加密密钥。不要将数据文件放网络共享盘或让多个进程共享写库。

```sh
curl http://127.0.0.1:8787/healthz
```

提交、操作查询、变更读取的请求和返回格式见[完整HTTP协议](docs/protocol.md)。初次从日志起点分页重放，之后仅拉新提交；完整commit不拆页。冲突候选和原回执持久保存，重试同operation返回原结果，使用同身份提交不同内容会拒绝。当前没有自动清理历史、墓碑和回执，长期容量与压缩另行实现。

## 大内容、配对与恢复

- 单个不可变对象支持0–256MiB，固定1MiB分块；每块完整确认，重启后查询进度再续传。只有整体SHA256验证通过的对象能被记录引用。128KiB仍是小JSON载荷预算，不是整个数据库容量。
- 管理员签发10分钟、一次性的配对凭证，限定应用/空间和设备期限；新设备自行生成访问token，服务仅存摘要。撤销/过期后令牌立即失效，传输中的请求在写入前也会复核。其他获授权设备仍能恢复既有内容。
- 对象、历史、删除标记和操作回执放在同一SQLite中并永久保留；仅过期上传/配对临时数据可清理。未做总容量配额和自动GC，实际容量受磁盘限制。
- 正常停服后复制数据库可保留历史与冲突引用闭包。恢复旧备份使用`node scripts/prepare-restore.mjs 备份.sqlite 全新目标.sqlite`，复制并更换游标身份；不会覆盖已有文件。重新引导前保留客户端待同步内容，并隔离网络核对旧备份中的设备权限。

当前数据库schema=2；旧测试schema=1明确拒绝打开，不自动迁移或清空。如要测试新设计，请显式使用新的数据库路径。详细接口、错误和恢复边界以[协议](docs/protocol.md)为准。

## 客户端 SDK 与加密

包名`@tulai-design/sync-sdk@0.1.0`，当前仅本地打包验证，尚未发布npm。公开ESM和TypeScript声明，无React/Dexie/Tauri依赖：

```ts
import {createSyncClient} from '@tulai-design/sync-sdk'
import {encryptRecord, decryptRecord} from '@tulai-design/sync-sdk/crypto'
```

SDK处理有限重试、原操作查询、固定水位分页、取消/超时、对象上传续传与暂存下载。加密使用原生AES-256-GCM和PBKDF2口令包装随机空间keyring；轮换添加新写key、保留历史读key。最终密文必须先持久化，重试复用同一操作ID与同一字节。产品outbox/入站cursor事务和密钥管理UI仍由产品实现，尚未正式接入。

完整API和接入约束见[客户端说明](docs/client.md)、[加密格式](docs/encryption.md)。服务仍能看到实体标识、版本、删除标记和对象长度等元数据；本轮不宣称完成外部密码协议审计、全量历史重加密或生产部署验收。

## 检查与目录

```sh
node scripts/check.mjs
node --test tests/*.test.mjs
# 安装开发依赖后：pnpm check:types
```

也可使用本机兼容pnpm的`check`、`test`、`start`脚本。`check`是语法检查，新增`check:types`验证公开SDK类型消费；本仓没有独立lint或编译构建命令。测试使用临时数据库、随机凭据、loopback服务和真实子进程，不连接真实账户。

```text
apps/server/          HTTP入口、配置启动、SQLite事务
packages/protocol/    纯JSON校验、协议错误与预算
packages/client/      通用HTTP客户端、客户端加密与类型声明
scripts/             语法检查、离线恢复副本准备
tests/               HTTP、存储与跨进程契约测试
docs/                架构方向与协议唯一正文
.trellis/            服务自身的任务、规范与验收
```

SDK已提供，部署目录在对应任务开始时建立。服务与产品的职责见[架构方向](docs/architecture.md)；开发前读[AGENTS.md](AGENTS.md)和[文档索引](docs/README.md)。服务可与搭搭同机部署，但协议/镜像独立版本化；业务适配、本地事务、队列和冲突界面仍归各产品。
