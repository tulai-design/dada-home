/** 纯 JSON 协议边界；不依赖 Node、存储或产品类型。 */
export const LIMITS = Object.freeze({requestBytes: 262144, payloadBytes: 131072, mutations: 100, depth: 32, pageCommits: 20})
export const OBJECT_LIMITS = Object.freeze({objectBytes: 268435456, chunkBytes: 1048576, refs: 32, activeUploads: 8, uploadTtlMs: 86400000})
export class ProtocolError extends Error {
  constructor(status, code, message) {super(message); this.name = 'ProtocolError'; this.status = status; this.code = code}
}
const encoder = new TextEncoder()
const fail = (message = '请求格式无效。') => {throw new ProtocolError(400, 'invalid_request', message)}
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value))
const exact = (value, keys) => {
  if (!object(value) || Reflect.ownKeys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value, key)) || Reflect.ownKeys(value).some(key => !keys.includes(key))) fail()
  if (Object.values(Object.getOwnPropertyDescriptors(value)).some(d => !('value' in d))) fail()
}
function json(value, depth, seen, maxDepth) {
  if (depth > maxDepth) fail('JSON 层级超过限制。')
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'number') {if (!Number.isFinite(value)) fail('JSON 数字必须有限。'); return JSON.stringify(value)}
  if (typeof value !== 'object' || seen.has(value)) fail('必须提供完整 JSON 值。')
  seen.add(value)
  try {
    if (Array.isArray(value)) {
      if (Reflect.ownKeys(value).length !== value.length + 1) fail('数组不能包含空位或额外字段。')
      return '[' + Array.from({length: value.length}, (_, index) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index))
        if (!descriptor || !('value' in descriptor)) fail('数组不能包含空位或访问器。')
        return json(descriptor.value, depth + 1, seen, maxDepth)
      }).join(',') + ']'
    }
    if (!object(value)) fail('必须提供普通 JSON 对象。')
    const descriptors = Object.getOwnPropertyDescriptors(value)
    if (Reflect.ownKeys(value).some(key => typeof key !== 'string') || Object.values(descriptors).some(d => !('value' in d) || !d.enumerable)) fail()
    return '{' + Object.keys(descriptors).sort().map(key => JSON.stringify(key) + ':' + json(descriptors[key].value, depth + 1, seen, maxDepth)).join(',') + '}'
  } finally {seen.delete(value)}
}
export function canonical(value) {return json(value, 0, new Set(), LIMITS.depth + 8)}
export function validateId(value, label = '标识') {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(value)) fail(`${label}格式无效。`)
  return value
}
export function validateScope(value) {
  exact(value, ['appId', 'spaceId'])
  return {appId: validateId(value.appId, '应用标识'), spaceId: validateId(value.spaceId, '空间标识')}
}
export function validateObjectHash(value) {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) fail('对象摘要必须为 SHA-256 小写十六进制。')
  return value
}
export function validateObjectDescriptor(raw) {
  exact(raw, ['sha256', 'byteLength'])
  const sha256 = validateObjectHash(raw.sha256)
  if (!Number.isSafeInteger(raw.byteLength) || raw.byteLength < 0) fail('对象长度必须为非负安全整数。')
  if (raw.byteLength > OBJECT_LIMITS.objectBytes) throw new ProtocolError(413, 'payload_too_large', '单个对象超过 256 MiB。')
  return {sha256, byteLength: raw.byteLength}
}
function validateObjectRefs(value) {
  if (!Array.isArray(value) || value.length > OBJECT_LIMITS.refs) fail('对象引用最多 32 个。')
  // 在读取数组元素前验证无空位、访问器或额外字段。
  canonical(value)
  const seen = new Set()
  return value.map(raw => {
    const ref = validateObjectDescriptor(raw)
    if (seen.has(ref.sha256)) fail('对象引用不能重复。')
    seen.add(ref.sha256)
    return ref
  })
}
export function validateBatch(raw) {
  exact(raw, ['protocolVersion', 'operationId', 'mutations'])
  if (raw.protocolVersion !== 1) throw new ProtocolError(400, 'unsupported_version', '不支持此协议版本。')
  const operationId = validateId(raw.operationId, '操作标识')
  if (!Array.isArray(raw.mutations) || raw.mutations.length < 1 || raw.mutations.length > LIMITS.mutations) fail('提交需包含 1–100 条变更。')
  const identities = new Set()
  const mutations = raw.mutations.map(mutation => {
    if (!object(mutation)) fail()
    exact(mutation, mutation.type === 'put' ? ['type', 'collection', 'entityId', 'baseRevision', 'schemaVersion', 'payload', ...(Object.hasOwn(mutation, 'objectRefs') ? ['objectRefs'] : [])] : ['type', 'collection', 'entityId', 'baseRevision'])
    if (!['put', 'delete'].includes(mutation.type)) fail('不支持此变更类型。')
    const collection = validateId(mutation.collection, '集合标识'), entityId = mutation.entityId, baseRevision = mutation.baseRevision
    if (typeof entityId !== 'string' || !entityId.length || !entityId.isWellFormed() || encoder.encode(entityId).byteLength > 256 || /[\u0000-\u001f\u007f]/.test(entityId)) fail('记录标识格式无效。')
    if (baseRevision !== null && (!Number.isSafeInteger(baseRevision) || baseRevision < 1)) fail('基础版本无效。')
    const identity = JSON.stringify([collection, entityId])
    if (identities.has(identity)) fail('同一批次不能重复修改同一记录。')
    identities.add(identity)
    const result = {type: mutation.type, collection, entityId, baseRevision}
    if (mutation.type === 'put') {
      if (!Number.isSafeInteger(mutation.schemaVersion) || mutation.schemaVersion < 1) fail('数据版本无效。')
      const text = json(mutation.payload, 0, new Set(), LIMITS.depth)
      if (encoder.encode(text).byteLength > LIMITS.payloadBytes) throw new ProtocolError(413, 'payload_too_large', '单条数据超过 128 KiB。')
      result.schemaVersion = mutation.schemaVersion
      result.payload = JSON.parse(text)
      if (Object.hasOwn(mutation, 'objectRefs')) result.objectRefs = validateObjectRefs(mutation.objectRefs)
    }
    return result
  })
  // 全请求规范化也验证 mutations 自身无空位、额外属性等非 JSON 内容。
  if (encoder.encode(canonical(raw)).byteLength > LIMITS.requestBytes) throw new ProtocolError(413, 'payload_too_large', '请求超过 256 KiB。')
  return {protocolVersion: 1, operationId, mutations}
}
