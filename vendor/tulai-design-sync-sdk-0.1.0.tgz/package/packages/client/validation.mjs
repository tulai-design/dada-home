import {LIMITS, OBJECT_LIMITS, canonical, validateBatch, validateId, validateScope, validateObjectDescriptor, validateObjectHash} from '../protocol/index.mjs'

const bad = () => {throw new Error('Invalid protocol value')}
export const object = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value))
export function exact(value, keys) {
  if (!object(value) || Reflect.ownKeys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value, key)) || Reflect.ownKeys(value).some(key => !keys.includes(key))) bad()
  if (Object.values(Object.getOwnPropertyDescriptors(value)).some(d => !('value' in d) || !d.enumerable)) bad()
  return value
}
export const integer = (value, min = 1, max = Number.MAX_SAFE_INTEGER) => {if (!Number.isSafeInteger(value) || value < min || value > max) bad(); return value}
export const token = value => {if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{32,128}$/.test(value)) bad(); return value}
export const cursor = value => {if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,2048}$/.test(value)) bad(); return value}
export const version = value => {if (value !== 1) bad()}
export const boolean = value => {if (typeof value !== 'boolean') bad(); return value}
export function array(value, min, max) {
  if (!Array.isArray(value) || value.length < min || value.length > max || Reflect.ownKeys(value).length !== value.length + 1) bad()
  for (let i = 0; i < value.length; i++) {const d = Object.getOwnPropertyDescriptor(value, String(i)); if (!d || !('value' in d)) bad()}
  return value
}
function entity(value) {validateBatch({protocolVersion: 1, operationId: 'validate', mutations: [{type: 'delete', collection: 'validate', entityId: value, baseRevision: null}]}); return value}
const identity = value => JSON.stringify([value.collection, value.entityId])
function unique(values, key) {const seen = new Set(); for (const value of values) {const id = key(value); if (seen.has(id)) bad(); seen.add(id)}}
export function scopes(value) {array(value, 1, LIMITS.requestBytes); value.forEach(validateScope); unique(value, scope => JSON.stringify([scope.appId, scope.spaceId])); return value}
export function capabilities(value) {
  exact(value, ['protocolVersion', 'records', 'atomicBatch', 'idempotency', 'changeLog', 'objects', 'encryption', 'dynamicDevices', 'limits', 'objectLimits']); version(value.protocolVersion)
  for (const key of ['records', 'atomicBatch', 'idempotency', 'changeLog', 'objects', 'encryption', 'dynamicDevices']) boolean(value[key])
  for (const [key, expected] of [['limits', LIMITS], ['objectLimits', OBJECT_LIMITS]]) {
    exact(value[key], Object.keys(expected)); for (const name of Object.keys(expected)) if (value[key][name] !== expected[name]) bad()
  }
  return value
}
export function receipt(value, request) {
  if (value?.status === 'committed') {
    exact(value, ['protocolVersion', 'operationId', 'status', 'revision', 'records']); integer(value.revision)
    array(value.records, 1, LIMITS.mutations)
    for (const record of value.records) {
      exact(record, ['collection', 'entityId', 'revision', 'deleted']); validateId(record.collection); entity(record.entityId); boolean(record.deleted)
      if (record.revision !== value.revision) bad()
    }
    unique(value.records, identity)
    if (request?.mutations.some(m => m.baseRevision !== null && m.baseRevision >= value.revision)) bad()
    if (request && (value.records.length !== request.mutations.length || value.records.some((record, i) => identity(record) !== identity(request.mutations[i]) || record.deleted !== (request.mutations[i].type === 'delete')))) bad()
  } else if (value?.status === 'conflict') {
    exact(value, ['protocolVersion', 'operationId', 'status', 'conflicts']); array(value.conflicts, 1, LIMITS.mutations)
    for (const conflict of value.conflicts) {
      exact(conflict, ['collection', 'entityId', 'baseRevision', 'currentRevision']); validateId(conflict.collection); entity(conflict.entityId)
      if (conflict.baseRevision !== null) integer(conflict.baseRevision)
      if (conflict.currentRevision !== null) integer(conflict.currentRevision)
      if (conflict.baseRevision === conflict.currentRevision) bad()
      if (request && !request.mutations.some(m => identity(m) === identity(conflict) && m.baseRevision === conflict.baseRevision)) bad()
    }
    unique(value.conflicts, identity)
  } else bad()
  version(value.protocolVersion); validateId(value.operationId)
  if (request && value.operationId !== request.operationId) bad()
  return value
}
export function operation(value, operationId) {
  exact(value, ['protocolVersion', 'request', 'receipt']); version(value.protocolVersion)
  const request = validateBatch(value.request)
  if (request.operationId !== operationId) bad()
  receipt(value.receipt, request)
  return value
}
export function changes(value, limit = LIMITS.pageCommits) {
  exact(value, ['protocolVersion', 'commits', 'cursor', 'hasMore']); version(value.protocolVersion); cursor(value.cursor); boolean(value.hasMore)
  array(value.commits, 0, limit)
  if (value.hasMore && !value.commits.length) bad()
  let previous
  for (const commit of value.commits) {
    exact(commit, ['revision', 'deviceId', 'operationId', 'records']); integer(commit.revision); validateId(commit.deviceId); validateId(commit.operationId)
    if (previous !== undefined && commit.revision !== previous + 1) bad()
    previous = commit.revision
    array(commit.records, 1, LIMITS.mutations)
    const mutations = commit.records.map(record => {
      boolean(record?.deleted)
      exact(record, ['collection', 'entityId', 'revision', 'deleted', ...(record.deleted ? [] : ['schemaVersion', 'payload', ...(Object.hasOwn(record, 'objectRefs') ? ['objectRefs'] : [])])])
      if (record.revision !== commit.revision) bad()
      return record.deleted ? {type: 'delete', collection: record.collection, entityId: record.entityId, baseRevision: null} : {type: 'put', collection: record.collection, entityId: record.entityId, baseRevision: null, schemaVersion: record.schemaVersion, payload: record.payload, ...(Object.hasOwn(record, 'objectRefs') ? {objectRefs: record.objectRefs} : {})}
    })
    validateBatch({protocolVersion: 1, operationId: commit.operationId, mutations})
  }
  return value
}
export function upload(value, expected) {
  const complete = value?.status === 'complete'
  exact(value, ['protocolVersion', 'status', 'sha256', 'byteLength', 'chunkBytes', 'chunkCount', ...(complete ? [] : ['uploadId', 'received', 'expiresAt'])])
  version(value.protocolVersion)
  if (!complete && value.status !== 'uploading') bad()
  const descriptor = validateObjectDescriptor({sha256: value.sha256, byteLength: value.byteLength})
  if (value.chunkBytes !== OBJECT_LIMITS.chunkBytes || value.chunkCount !== Math.ceil(value.byteLength / OBJECT_LIMITS.chunkBytes)) bad()
  if (expected && (descriptor.sha256 !== expected.sha256 || descriptor.byteLength !== expected.byteLength)) bad()
  if (!complete) {
    validateId(value.uploadId); integer(value.expiresAt); array(value.received, 0, value.chunkCount)
    let previous = -1
    for (const index of value.received) {integer(index, 0, value.chunkCount - 1); if (index <= previous) bad(); previous = index}
  }
  return value
}
export function completeObject(value, hash) {upload(value); if (value.status !== 'complete' || value.sha256 !== hash) bad(); return value}
export function pairingInput(value) {
  exact(value, ['deviceId', 'scopes', 'expiresAt']); validateId(value.deviceId); scopes(value.scopes)
  if (value.expiresAt !== null) integer(value.expiresAt)
  return JSON.parse(canonical(value))
}
export function pairing(value, deviceId) {
  exact(value, ['protocolVersion', 'deviceId', 'pairingToken', 'expiresAt']); version(value.protocolVersion); validateId(value.deviceId); token(value.pairingToken); integer(value.expiresAt)
  if (value.deviceId !== deviceId) bad()
  return value
}
function device(value) {
  exact(value, ['id', 'scopes', 'expiresAt', 'revokedAt', 'kind']); validateId(value.id); scopes(value.scopes)
  if (!['paired', 'administrator'].includes(value.kind)) bad()
  for (const key of ['expiresAt', 'revokedAt']) if (value[key] !== null) integer(value[key], 0)
  if (value.kind === 'administrator' && (value.expiresAt !== null || value.revokedAt !== null)) bad()
  return value
}
export function deviceResult(value, id) {exact(value, ['protocolVersion', 'device']); version(value.protocolVersion); device(value.device); if (id !== undefined && value.device.id !== id) bad(); return value}
export function devices(value) {exact(value, ['protocolVersion', 'devices']); version(value.protocolVersion); array(value.devices, 0, 256); value.devices.forEach(device); unique(value.devices, d => d.id); return value}
export function errorBody(value) {
  exact(value, ['protocolVersion', 'error']); version(value.protocolVersion); exact(value.error, ['code', 'message'])
  if (typeof value.error.code !== 'string' || !/^[a-z][a-z0-9_]{0,63}$/.test(value.error.code) || typeof value.error.message !== 'string' || value.error.message.length > 4096) bad()
  return value.error.code
}
export {validateBatch, validateId, validateScope, validateObjectDescriptor, validateObjectHash}
