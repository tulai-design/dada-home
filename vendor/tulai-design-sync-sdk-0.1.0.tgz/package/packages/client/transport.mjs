import {errorBody} from './validation.mjs'

const TRANSIENT = new Set([408, 429, 502, 503, 504])
const ERROR_CODES = new Set(['invalid_request', 'unsupported_version', 'invalid_cursor', 'unauthorized', 'forbidden', 'not_found', 'method_not_allowed', 'payload_too_large', 'unsupported_media_type', 'idempotency_mismatch', 'storage_unavailable', 'internal_error', 'object_missing', 'upload_expired', 'upload_limit', 'chunk_mismatch', 'upload_incomplete', 'integrity_mismatch', 'pairing_expired', 'device_exists', 'token_in_use', 'device_limit', 'pairing_limit'])
export class SyncClientError extends Error {
  constructor(code, {status, retryable = false, mayHaveCommitted = false} = {}) {
    super(`同步请求失败（${ERROR_CODES.has(code) || ['invalid_input', 'invalid_response', 'response_too_large', 'network_error', 'timeout', 'integrity_mismatch', 'checkpoint_mismatch', 'source_changed', 'source_failed', 'sink_failed', 'checkpoint_failed'].includes(code) ? code : 'request_failed'}）。`)
    this.name = 'SyncClientError'; this.code = code; this.status = status; this.retryable = retryable; this.mayHaveCommitted = mayHaveCommitted
  }
}
export function abortError(mayHaveCommitted = false) {const error = new DOMException('同步操作已取消。', 'AbortError'); Object.defineProperty(error, 'mayHaveCommitted', {value: mayHaveCommitted}); return error}
export function checkAbort(signal) {if (signal?.aborted) throw abortError()}
export function input(work) {try {return work()} catch {throw new SyncClientError('invalid_input')}}
export function response(work, write = false) {try {return work()} catch {throw new SyncClientError('invalid_response', {mayHaveCommitted: write})}}
export async function cancellable(work, signal) {
  checkAbort(signal)
  if (!signal) return work
  let onAbort
  const aborted = new Promise((_, reject) => {onAbort = () => reject(abortError()); signal.addEventListener('abort', onAbort, {once: true})})
  try {return await Promise.race([work, aborted])} finally {signal.removeEventListener('abort', onAbort)}
}
async function delay(ms, signal) {
  checkAbort(signal)
  await new Promise((resolve, reject) => {
    const finish = () => {signal?.removeEventListener('abort', onAbort); resolve()}
    const timer = setTimeout(finish, ms)
    const onAbort = () => {clearTimeout(timer); reject(abortError())}
    signal?.addEventListener('abort', onAbort, {once: true})
  })
}
async function read(response, budget, signal) {
  const length = response.headers.get('content-length')
  if (length !== null && (!/^\d+$/.test(length) || Number(length) > budget)) {
    void response.body?.cancel().catch(() => {})
    throw new SyncClientError('response_too_large')
  }
  const reader = response.body?.getReader()
  if (!reader) throw new SyncClientError('invalid_response')
  const chunks = []; let size = 0, complete = false
  try {
    while (true) {
      const {value, done} = await cancellable(reader.read(), signal)
      if (done) break
      if (!(value instanceof Uint8Array)) throw new SyncClientError('invalid_response')
      size += value.byteLength
      if (size > budget) throw new SyncClientError('response_too_large')
      chunks.push(value)
    }
    if (length !== null && size !== Number(length)) throw new SyncClientError('invalid_response')
    const bytes = new Uint8Array(size); let offset = 0
    for (const chunk of chunks) {bytes.set(chunk, offset); offset += chunk.byteLength}
    complete = true
    return bytes
  } finally {
    if (!complete) void reader.cancel().catch(() => {})
    reader.releaseLock()
  }
}
export function createTransport({baseUrl, token, fetchImpl, retries, timeoutMs}) {
  return async function request(path, {method = 'GET', body, binary = false, signal, retry = true, budget = 1048576, acceptConflict = false, notFound = false, authorize = true} = {}) {
    const url = baseUrl + path, write = method !== 'GET'
    const headers = {Accept: binary ? 'application/octet-stream, application/json' : 'application/json', ...(authorize ? {Authorization: `Bearer ${token}`} : {}), ...(body === undefined ? {} : {'Content-Type': body instanceof Uint8Array ? 'application/octet-stream' : 'application/json'})}
    let uncertain = false
    for (let attempt = 0; ; attempt++) {
      if (signal?.aborted) throw abortError(uncertain)
      const controller = new AbortController()
      let timedOut = false
      const onAbort = () => controller.abort()
      signal?.addEventListener('abort', onAbort, {once: true})
      const timer = setTimeout(() => {timedOut = true; controller.abort()}, timeoutMs)
      let failure
      try {
        const res = await cancellable(Promise.resolve().then(() => {checkAbort(controller.signal); return fetchImpl(url, {method, headers: {...headers}, ...(body === undefined ? {} : {body: body instanceof Uint8Array ? new Uint8Array(body) : body}), signal: controller.signal, redirect: 'error', credentials: 'omit', cache: 'no-store'})}), controller.signal)
        const bytes = await read(res, budget, controller.signal)
        checkAbort(controller.signal)
        const success = res.status === 200
        const media = res.headers.get('content-type') ?? ''
        if (success && binary) {
          if (!/^application\/octet-stream(?:\s*)$/i.test(media)) throw new SyncClientError('invalid_response')
          return {bytes, hash: res.headers.get('x-content-sha256')}
        }
        if (!/^application\/json(?:\s*;\s*charset\s*=\s*(?:utf-8|"utf-8"))?\s*$/i.test(media)) throw new SyncClientError('invalid_response', {status: res.status, retryable: TRANSIENT.has(res.status), mayHaveCommitted: write})
        let value
        try {value = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(bytes))} catch {throw new SyncClientError('invalid_response', {status: res.status, retryable: TRANSIENT.has(res.status), mayHaveCommitted: write})}
        if (success && acceptConflict && value?.status === 'conflict') throw new SyncClientError('invalid_response', {status: res.status, mayHaveCommitted: write})
        if (success || (acceptConflict && res.status === 409 && value?.status === 'conflict')) return value
        let code
        try {code = errorBody(value)} catch {throw new SyncClientError('invalid_response', {status: res.status, retryable: TRANSIENT.has(res.status), mayHaveCommitted: write})}
        if (notFound && res.status === 404 && code === 'not_found') return undefined
        throw new SyncClientError(ERROR_CODES.has(code) ? code : 'http_error', {status: res.status, retryable: TRANSIENT.has(res.status), mayHaveCommitted: write && TRANSIENT.has(res.status)})
      } catch (error) {
        if (signal?.aborted) throw abortError(write)
        if (timedOut) failure = new SyncClientError('timeout', {retryable: true, mayHaveCommitted: write})
        else if (error instanceof SyncClientError) {failure = error; if (write && error.status === undefined) failure.mayHaveCommitted = true}
        else failure = new SyncClientError('network_error', {retryable: true, mayHaveCommitted: write})
      } finally {clearTimeout(timer); signal?.removeEventListener('abort', onAbort)}
      uncertain ||= failure.mayHaveCommitted
      failure.mayHaveCommitted ||= uncertain
      if (!retry || !failure.retryable || attempt >= retries) throw failure
      try {await delay(Math.min(100 * 2 ** attempt, 1000), signal)} catch {throw abortError(uncertain)}
    }
  }
}
