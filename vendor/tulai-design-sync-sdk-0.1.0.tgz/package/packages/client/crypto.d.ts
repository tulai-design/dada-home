import type {ByteSource, ObjectDescriptor, TransactionalSink} from './index.js'

export type CryptoScope = {appId: string; spaceId: string}
export type CryptoContext = CryptoScope & {collection: string; entityId: string; schemaVersion: number}
export type Keyring = CryptoScope & {format: 'tulai-keyring'; version: 1; activeKeyId: string; keys: {id: string; key: string}[]}
export type WrappedKeyring = CryptoScope & {format: 'tulai-keyring-wrapped'; version: 1; kdf: 'PBKDF2-SHA256'; iterations: 600000; salt: string; iv: string; ciphertext: string}
export type EncryptedEnvelope = {format: 'tulai-encrypted'; version: 1; keyId: string; iv: string; ciphertext: string}
export type PreparedObject = {descriptor: ObjectDescriptor; manifest: EncryptedEnvelope}
export type CryptoOptions = {keyring: Keyring; context: CryptoContext; signal?: AbortSignal}
export type CryptoErrorCode = 'invalid_context' | 'invalid_keyring' | 'invalid_passphrase' | 'invalid_envelope' | 'unknown_key' | 'decryption_failed' | 'payload_too_large' | 'invalid_payload' | 'invalid_source' | 'invalid_sink' | 'source_failed' | 'sink_failed' | 'integrity_mismatch' | 'crypto_unavailable'
export class CryptoError extends Error {readonly code: CryptoErrorCode; constructor(code: CryptoErrorCode)}

/** 明文密钥材料，仅供内存或受控备份；不会调用网络或保存密钥。 */
export function createKeyring(scope: CryptoScope): Keyring
export function rotateKeyring(keyring: Keyring): Keyring
export function wrapKeyring(keyring: Keyring, passphrase: string): Promise<WrappedKeyring>
export function unwrapKeyring(envelope: unknown, passphrase: string, scope: CryptoScope): Promise<Keyring>
/** 调用方应在首次发送前持久化最终密文；相同操作重试必须复用相同密文。 */
export function encryptRecord(payload: unknown, keyring: Keyring, context: CryptoContext): Promise<EncryptedEnvelope>
export function decryptRecord(envelope: unknown, keyring: Keyring, context: CryptoContext): Promise<unknown>
/** sink 必须隔离暂存；仅 commit 成功后才发布，失败会调用 abort。 */
export function encryptObject(source: ByteSource, sink: TransactionalSink, options: CryptoOptions): Promise<PreparedObject>
export function decryptObject(source: ByteSource, prepared: PreparedObject, sink: TransactionalSink, options: CryptoOptions): Promise<ObjectDescriptor>
