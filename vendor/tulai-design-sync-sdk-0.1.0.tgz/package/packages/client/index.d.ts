export type JsonValue = null | boolean | number | string | JsonValue[] | {[key: string]: JsonValue};
export interface Scope {appId: string; spaceId: string}
export interface ObjectDescriptor {sha256: string; byteLength: number}
export interface RequestOptions {signal?: AbortSignal}
export interface ChangeOptions extends RequestOptions {cursor?: string; limit?: number}
export interface SyncClientOptions extends Scope {
  baseUrl: string;
  token: string;
  fetchImpl?: typeof globalThis.fetch;
  /** Number of retries after the initial attempt, from 0 to 3. */
  retries?: number;
  /** Per-attempt timeout, including reading the response body. */
  timeoutMs?: number;
}
export interface PutMutation {
  type: 'put'; collection: string; entityId: string; baseRevision: number | null;
  schemaVersion: number; payload: JsonValue; objectRefs?: ObjectDescriptor[];
}
export interface DeleteMutation {type: 'delete'; collection: string; entityId: string; baseRevision: number | null}
export type Mutation = PutMutation | DeleteMutation;
export interface CommitBatch {protocolVersion: 1; operationId: string; mutations: Mutation[]}
export interface RecordIdentity {collection: string; entityId: string; revision: number; deleted: boolean}
export interface LiveRecord extends RecordIdentity {deleted: false; schemaVersion: number; payload: JsonValue; objectRefs?: ObjectDescriptor[]}
export interface Tombstone extends RecordIdentity {deleted: true}
export type SyncRecord = LiveRecord | Tombstone;
export interface CommittedReceipt {protocolVersion: 1; operationId: string; status: 'committed'; revision: number; records: RecordIdentity[]}
export interface RecordConflict {collection: string; entityId: string; baseRevision: number | null; currentRevision: number | null}
export interface ConflictReceipt {protocolVersion: 1; operationId: string; status: 'conflict'; conflicts: RecordConflict[]}
export type CommitReceipt = CommittedReceipt | ConflictReceipt;
export interface OperationResult {protocolVersion: 1; request: CommitBatch; receipt: CommitReceipt}
export interface ChangeCommit {revision: number; deviceId: string; operationId: string; records: SyncRecord[]}
export interface ChangePage {protocolVersion: 1; commits: ChangeCommit[]; cursor: string; hasMore: boolean}
export interface ProtocolLimits {requestBytes: number; payloadBytes: number; mutations: number; depth: number; pageCommits: number}
export interface ObjectLimits {objectBytes: number; chunkBytes: number; refs: number; activeUploads: number; uploadTtlMs: number}
export interface Capabilities {
  protocolVersion: 1; records: boolean; atomicBatch: boolean; idempotency: boolean; changeLog: boolean;
  objects: boolean; encryption: boolean; dynamicDevices: boolean; limits: ProtocolLimits; objectLimits: ObjectLimits;
}
export interface CompleteObject extends ObjectDescriptor {protocolVersion: 1; status: 'complete'; chunkBytes: number; chunkCount: number}
export interface PendingUpload extends ObjectDescriptor {
  protocolVersion: 1; status: 'uploading'; uploadId: string; chunkBytes: number; chunkCount: number;
  received: number[]; expiresAt: number;
}
export type UploadStatus = PendingUpload | CompleteObject;
/** The source must remain an immutable snapshot for the entire operation. */
export type ByteSource = Blob | {byteLength: number; read(offset: number, length: number): Promise<Uint8Array>};
/** write() stages bytes; only commit() may publish them. abort() must discard staged bytes. */
export interface TransactionalSink {
  write(offset: number, bytes: Uint8Array): Promise<void>;
  commit(): Promise<void>;
  abort(error: unknown): Promise<void>;
}
export interface UploadCheckpoint extends Scope, ObjectDescriptor {uploadId: string}
export interface UploadOptions extends RequestOptions {
  checkpoint?: UploadCheckpoint;
  /** Awaited after a new upload is created and before any chunk is sent. */
  onCheckpoint?(checkpoint: UploadCheckpoint): Promise<void> | void;
}
export interface PairInput {deviceId: string; scopes: Scope[]; expiresAt: number | null}
export interface Pairing {protocolVersion: 1; deviceId: string; pairingToken: string; expiresAt: number}
export interface RedeemInput {pairingToken: string; token: string}
export interface Device {id: string; scopes: Scope[]; expiresAt: number | null; revokedAt: number | null; kind: 'administrator' | 'paired'}
export interface DeviceResult {protocolVersion: 1; device: Device}
export interface DevicesResult {protocolVersion: 1; devices: Device[]}
export class SyncClientError extends Error {
  constructor(code: string, options?: {status?: number; retryable?: boolean; mayHaveCommitted?: boolean});
  readonly name: 'SyncClientError'; readonly code: string; readonly status: number | undefined;
  readonly retryable: boolean;
  /** An uncertain write must be resolved through its original operation or upload identity. */
  readonly mayHaveCommitted: boolean;
}
export interface SyncClient {
  capabilities(options?: RequestOptions): Promise<Capabilities>;
  commit(batch: CommitBatch, options?: RequestOptions): Promise<CommitReceipt>;
  operation(operationId: string, options?: RequestOptions): Promise<OperationResult | undefined>;
  changes(options?: ChangeOptions): Promise<ChangePage>;
  /** Pull the next page only after the current page's local transaction succeeds. */
  pages(options?: ChangeOptions): AsyncGenerator<ChangePage, void, unknown>;
  createUpload(descriptor: ObjectDescriptor, options?: RequestOptions): Promise<UploadStatus>;
  uploadStatus(uploadId: string, options?: RequestOptions): Promise<UploadStatus>;
  putChunk(uploadId: string, index: number, bytes: Uint8Array, options?: RequestOptions): Promise<UploadStatus>;
  completeUpload(uploadId: string, options?: RequestOptions): Promise<CompleteObject>;
  object(sha256: string, options?: RequestOptions): Promise<CompleteObject | undefined>;
  objectChunk(sha256: string, index: number, options?: RequestOptions): Promise<Uint8Array>;
  uploadObject(source: ByteSource, options?: UploadOptions): Promise<ObjectDescriptor>;
  downloadObject(descriptor: ObjectDescriptor, sink: TransactionalSink, options?: RequestOptions): Promise<ObjectDescriptor>;
  pair(input: PairInput, options?: RequestOptions): Promise<Pairing>;
  redeem(input: RedeemInput, options?: RequestOptions): Promise<DeviceResult>;
  devices(options?: RequestOptions): Promise<DevicesResult>;
  revoke(deviceId: string, options?: RequestOptions): Promise<DeviceResult>;
}
export function createSyncClient(options: SyncClientOptions): SyncClient;
