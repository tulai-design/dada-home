import {sha256} from '@noble/hashes/sha2.js'
import {canonical, LIMITS, OBJECT_LIMITS} from '../protocol/index.mjs'
import * as v from './validation.mjs'
import {SyncClientError, checkAbort, cancellable, input, response, createTransport} from './transport.mjs'
export {SyncClientError} from './transport.mjs'

const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')
const descriptorOf = value => ({sha256: value.sha256, byteLength: value.byteLength})
const sameDescriptor = (a, b) => a.sha256 === b.sha256 && a.byteLength === b.byteLength
const opts = options => input(() => {
  if (options === undefined) return {}
  v.exact(options, Object.hasOwn(options, 'signal') ? ['signal'] : [])
  if (options.signal !== undefined && !(options.signal instanceof AbortSignal)) throw new Error()
  return {signal: options.signal}
})
function sourceOf(source) {
  return input(() => {
    if (typeof Blob !== 'undefined' && source instanceof Blob) {
      v.integer(source.size, 0, OBJECT_LIMITS.objectBytes)
      return {byteLength: source.size, read: async (offset, length) => new Uint8Array(await source.slice(offset, offset + length).arrayBuffer())}
    }
    if (!source || typeof source.read !== 'function') throw new Error()
    const byteLength = v.integer(source.byteLength, 0, OBJECT_LIMITS.objectBytes)
    return {byteLength, read: source.read.bind(source)}
  })
}
async function readSource(source, offset, length, signal) {
  checkAbort(signal)
  let bytes
  try {bytes = await cancellable(Promise.resolve().then(() => source.read(offset, length)), signal)} catch {checkAbort(signal); throw new SyncClientError('source_failed')}
  checkAbort(signal)
  if (!(bytes instanceof Uint8Array) || bytes.byteLength !== length) throw new SyncClientError('source_changed')
  return new Uint8Array(bytes)
}
async function sourceDescriptor(source, signal) {
  checkAbort(signal)
  const hash = sha256.create()
  try {for (let offset = 0; offset < source.byteLength; offset += OBJECT_LIMITS.chunkBytes) hash.update(await readSource(source, offset, Math.min(OBJECT_LIMITS.chunkBytes, source.byteLength - offset), signal)); return {sha256: hex(hash.digest()), byteLength: source.byteLength}}
  finally {hash.destroy()}
}
export function createSyncClient(configuration) {
  const config = input(() => {
    v.exact(configuration, ['baseUrl', 'token', 'appId', 'spaceId', ...['fetchImpl', 'retries', 'timeoutMs'].filter(key => Object.hasOwn(configuration, key))])
    if (typeof configuration.baseUrl !== 'string') throw new Error()
    const url = new URL(configuration.baseUrl)
    if (url.username || url.password || url.search || url.hash || !['http:', 'https:'].includes(url.protocol) || (url.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname))) throw new Error()
    const scope = v.validateScope({appId: configuration.appId, spaceId: configuration.spaceId}), token = v.token(configuration.token)
    const fetchImpl = configuration.fetchImpl ?? globalThis.fetch
    if (typeof fetchImpl !== 'function') throw new Error()
    return {baseUrl: url.href.replace(/\/+$/, ''), token, ...scope, fetchImpl, retries: v.integer(configuration.retries ?? 2, 0, 3), timeoutMs: v.integer(configuration.timeoutMs ?? 15000, 1, 300000)}
  })
  const request = createTransport(config), scope = {appId: config.appId, spaceId: config.spaceId}
  const root = `/v1/apps/${encodeURIComponent(scope.appId)}/spaces/${encodeURIComponent(scope.spaceId)}`
  const id = value => encodeURIComponent(input(() => v.validateId(value)))
  const hashPath = value => input(() => v.validateObjectHash(value))
  const indexPath = value => input(() => v.integer(value, 0, 255))
  const json = value => input(() => {const text = canonical(value); if (new TextEncoder().encode(text).byteLength > LIMITS.requestBytes) throw new Error(); return text})
  const client = {
    async capabilities(options) {const value = await request('/v1/capabilities', opts(options)); return response(() => v.capabilities(value))},
    async commit(raw, options) {
      const batch = input(() => v.validateBatch(raw)), settings = opts(options), bytes = json(batch)
      const value = await request(root + '/commits', {...settings, method: 'POST', body: bytes, acceptConflict: true})
      return response(() => v.receipt(value, batch), true)
    },
    async operation(operationId, options) {
      const target = id(operationId), settings = opts(options)
      const value = await request(root + '/operations/' + target, {...settings, notFound: true})
      return value === undefined ? undefined : response(() => v.operation(value, operationId))
    },
    async changes(options = {}) {
      const normalized = input(() => {
        v.exact(options, ['cursor', 'limit', 'signal'].filter(key => Object.hasOwn(options, key)))
        const settings = opts(Object.hasOwn(options, 'signal') ? {signal: options.signal} : {})
        return {...settings, ...(options.cursor !== undefined ? {cursor: v.cursor(options.cursor)} : {}), limit: options.limit === undefined ? LIMITS.pageCommits : v.integer(options.limit, 1, LIMITS.pageCommits)}
      })
      const query = new URLSearchParams({limit: String(normalized.limit)})
      if (normalized.cursor !== undefined) query.set('cursor', normalized.cursor)
      const value = await request(root + '/changes?' + query, {signal: normalized.signal, budget: 8 * 1048576})
      return response(() => v.changes(value, normalized.limit))
    },
    async *pages(options = {}) {
      const settings = {...options}, seen = new Set(settings.cursor === undefined ? [] : [settings.cursor])
      let previous
      while (true) {
        const page = await client.changes(settings)
        if (page.commits.length) {
          if (previous !== undefined && page.commits[0].revision !== previous + 1) throw new SyncClientError('invalid_response')
          previous = page.commits.at(-1).revision
        }
        if (seen.has(page.cursor) && (page.hasMore || page.commits.length)) throw new SyncClientError('invalid_response')
        seen.add(page.cursor)
        // next()由调用方在入站事务成功后继续；本地持久cursor不属于SDK。
        const nextCursor = page.cursor, hasMore = page.hasMore
        yield page
        if (!hasMore) return
        settings.cursor = nextCursor
      }
    },
    async createUpload(raw, options) {
      const descriptor = input(() => v.validateObjectDescriptor(raw)), settings = opts(options)
      const value = await request(root + '/uploads', {...settings, method: 'POST', body: json({protocolVersion: 1, ...descriptor}), retry: false})
      return response(() => v.upload(value, descriptor), true)
    },
    async uploadStatus(uploadId, options) {
      const target = id(uploadId), settings = opts(options), value = await request(root + '/uploads/' + target, settings)
      return response(() => {v.upload(value); if (value.status === 'uploading' && value.uploadId !== uploadId) throw new Error(); return value})
    },
    async putChunk(uploadId, index, bytes, options) {
      const target = id(uploadId), position = indexPath(index), settings = opts(options)
      const copy = input(() => {if (!(bytes instanceof Uint8Array) || bytes.byteLength > OBJECT_LIMITS.chunkBytes) throw new Error(); return new Uint8Array(bytes)})
      const value = await request(root + `/uploads/${target}/chunks/${position}`, {...settings, method: 'PUT', body: copy})
      return response(() => {v.upload(value); if (value.status === 'uploading' && (value.uploadId !== uploadId || !value.received.includes(index))) throw new Error(); return value}, true)
    },
    async completeUpload(uploadId, options) {
      const target = id(uploadId), settings = opts(options), value = await request(root + `/uploads/${target}/complete`, {...settings, method: 'POST', body: '{"protocolVersion":1}'})
      return response(() => {v.upload(value); if (value.status !== 'complete') throw new Error(); return value}, true)
    },
    async object(sha256, options) {
      const target = hashPath(sha256), settings = opts(options), value = await request(root + '/objects/' + target, {...settings, notFound: true})
      return value === undefined ? undefined : response(() => v.completeObject(value, target))
    },
    async objectChunk(hash, index, options) {
      const target = hashPath(hash), position = indexPath(index), settings = opts(options)
      const result = await request(root + `/objects/${target}/chunks/${position}`, {...settings, binary: true, budget: OBJECT_LIMITS.chunkBytes})
      if (!/^[0-9a-f]{64}$/.test(result.hash ?? '') || hex(sha256(result.bytes)) !== result.hash) throw new SyncClientError('integrity_mismatch')
      return result.bytes
    },
    async uploadObject(rawSource, options = {}) {
      const source = sourceOf(rawSource)
      const settings = input(() => {
        v.exact(options, ['checkpoint', 'onCheckpoint', 'signal'].filter(key => Object.hasOwn(options, key)))
        const settings = opts(Object.hasOwn(options, 'signal') ? {signal: options.signal} : {})
        if (options.onCheckpoint !== undefined && typeof options.onCheckpoint !== 'function') throw new Error()
        let checkpoint
        if (options.checkpoint !== undefined) {
          v.exact(options.checkpoint, ['appId', 'spaceId', 'sha256', 'byteLength', 'uploadId'])
          v.validateScope({appId: options.checkpoint.appId, spaceId: options.checkpoint.spaceId}); v.validateObjectDescriptor(descriptorOf(options.checkpoint)); v.validateId(options.checkpoint.uploadId)
          checkpoint = {...options.checkpoint}
        }
        return {...settings, checkpoint, onCheckpoint: options.onCheckpoint}
      })
      const descriptor = await sourceDescriptor(source, settings.signal), network = {signal: settings.signal}
      let state
      if (settings.checkpoint) {
        const cp = settings.checkpoint
        if (cp.appId !== scope.appId || cp.spaceId !== scope.spaceId || !sameDescriptor(cp, descriptor)) throw new SyncClientError('checkpoint_mismatch')
        try {state = await client.uploadStatus(cp.uploadId, network)} catch (error) {
          if (!(error instanceof SyncClientError) || !((error.status === 404 && error.code === 'not_found') || (error.status === 410 && error.code === 'upload_expired'))) throw error
        }
      }
      if (!state) {
        state = await client.createUpload(descriptor, network)
        if (state.status === 'uploading') {
          const checkpoint = {...scope, ...descriptor, uploadId: state.uploadId}
          if (settings.onCheckpoint) {
            try {await settings.onCheckpoint(checkpoint)} catch {checkAbort(settings.signal); throw new SyncClientError('checkpoint_failed')}
          }
          checkAbort(settings.signal)
        }
      }
      if (!sameDescriptor(state, descriptor)) throw new SyncClientError('checkpoint_mismatch')
      if (state.status === 'complete') return descriptor
      const uploadId = state.uploadId, received = new Set(state.received)
      for (let index = 0; index < state.chunkCount; index++) {
        if (received.has(index)) continue
        const bytes = await readSource(source, index * OBJECT_LIMITS.chunkBytes, Math.min(OBJECT_LIMITS.chunkBytes, source.byteLength - index * OBJECT_LIMITS.chunkBytes), settings.signal)
        const result = await client.putChunk(uploadId, index, bytes, network)
        if (!sameDescriptor(result, descriptor)) throw new SyncClientError('invalid_response', {mayHaveCommitted: true})
      }
      try {
        const complete = await client.completeUpload(uploadId, network)
        if (!sameDescriptor(complete, descriptor)) throw new SyncClientError('invalid_response', {mayHaveCommitted: true})
      } catch (error) {
        if (error?.name === 'AbortError' || !(error instanceof SyncClientError) || !error.mayHaveCommitted) throw error
        const complete = await client.object(descriptor.sha256, network)
        if (!complete || !sameDescriptor(complete, descriptor)) throw error
      }
      return descriptor
    },
    async downloadObject(raw, sink, options) {
      const descriptor = input(() => v.validateObjectDescriptor(raw)), settings = opts(options)
      input(() => {if (!sink || ['write', 'commit', 'abort'].some(key => typeof sink[key] !== 'function')) throw new Error()})
      const hash = sha256.create()
      try {
        checkAbort(settings.signal)
        const metadata = await client.object(descriptor.sha256, settings)
        if (!metadata) throw new SyncClientError('not_found', {status: 404})
        if (!sameDescriptor(metadata, descriptor)) throw new SyncClientError('integrity_mismatch')
        let offset = 0
        for (let index = 0; index < metadata.chunkCount; index++) {
          const bytes = await client.objectChunk(descriptor.sha256, index, settings)
          if (bytes.byteLength !== Math.min(OBJECT_LIMITS.chunkBytes, descriptor.byteLength - offset)) throw new SyncClientError('integrity_mismatch')
          hash.update(bytes)
          // 用户sink不可取消；等待写完成后才清理，避免abort之后迟到写重新留下暂存。
          try {await sink.write(offset, bytes)} catch {checkAbort(settings.signal); throw new SyncClientError('sink_failed')}
          checkAbort(settings.signal); offset += bytes.byteLength
        }
        if (offset !== descriptor.byteLength || hex(hash.digest()) !== descriptor.sha256) throw new SyncClientError('integrity_mismatch')
        checkAbort(settings.signal)
        try {await sink.commit()} catch {checkAbort(settings.signal); throw new SyncClientError('sink_failed')}
        return descriptor
      } catch (error) {try {await sink.abort(error)} catch { /* 保留导致暂存回滚的原始错误。 */ } throw error}
      finally {hash.destroy()}
    },
    async pair(raw, options) {
      const value = input(() => v.pairingInput(raw)), settings = opts(options)
      const result = await request('/v1/pairings', {...settings, method: 'POST', body: json({protocolVersion: 1, ...value}), retry: false})
      return response(() => v.pairing(result, value.deviceId), true)
    },
    async redeem(raw, options) {
      const value = input(() => {v.exact(raw, ['pairingToken', 'token']); return {protocolVersion: 1, pairingToken: v.token(raw.pairingToken), token: v.token(raw.token)}}), settings = opts(options)
      const result = await request('/v1/pairings/redeem', {...settings, method: 'POST', body: json(value), authorize: false})
      return response(() => {v.deviceResult(result); if (result.device.kind !== 'paired' || result.device.revokedAt !== null) throw new Error(); return result}, true)
    },
    async devices(options) {const value = await request('/v1/devices', opts(options)); return response(() => v.devices(value))},
    async revoke(deviceId, options) {
      const target = id(deviceId), settings = opts(options), result = await request('/v1/devices/' + target, {...settings, method: 'DELETE'})
      return response(() => {v.deviceResult(result, deviceId); if (result.device.kind !== 'paired' || result.device.revokedAt === null) throw new Error(); return result}, true)
    },
  }
  return Object.freeze(client)
}
