import {sha256} from '@noble/hashes/sha2.js'
import {canonical, LIMITS, OBJECT_LIMITS, validateBatch, validateId, validateObjectDescriptor, validateObjectHash, validateScope} from '../protocol/index.mjs'

const encoder = new TextEncoder(), decoder = new TextDecoder('utf-8', {fatal: true})
const ITERATIONS = 600_000, KEYRING_BYTES = 16 * 1024, TAG_BYTES = 16
const PLAIN_CHUNK = OBJECT_LIMITS.chunkBytes - TAG_BYTES, MAX_CHUNKS = OBJECT_LIMITS.objectBytes / OBJECT_LIMITS.chunkBytes
const MAX_PLAIN = PLAIN_CHUNK * MAX_CHUNKS
const messages = {
  invalid_context: '加密上下文无效。', invalid_keyring: '空间密钥格式无效。', invalid_passphrase: '加密口令无效。',
  invalid_envelope: '加密数据格式或版本无效。', unknown_key: '缺少读取该内容的空间密钥。', decryption_failed: '无法解密，请检查密钥与数据上下文。',
  payload_too_large: '加密数据超过预算，请改用受支持的对象大小。', invalid_payload: '加密内容必须是完整 JSON 值。',
  invalid_source: '对象来源或长度无效。', invalid_sink: '对象暂存接口无效。', source_failed: '无法读取对象来源。', sink_failed: '无法保存对象暂存内容。',
  integrity_mismatch: '对象长度或完整性校验失败。', crypto_unavailable: '当前环境无法执行加密操作。',
}
export class CryptoError extends Error {
  constructor(code) {super(messages[code] ?? '加密操作失败。'); this.name = 'CryptoError'; this.code = code}
}
const fail = code => {throw new CryptoError(code)}
const bytes = value => encoder.encode(value)
const jsonBytes = value => bytes(canonical(value))
const hex = value => Array.from(value, byte => byte.toString(16).padStart(2, '0')).join('')
function exact(value, keys, code) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail(code)
  const descriptors = Object.getOwnPropertyDescriptors(value), names = Reflect.ownKeys(descriptors)
  if (names.length !== keys.length || names.some(key => !keys.includes(key)) || keys.some(key => !Object.hasOwn(descriptors, key)) || Object.values(descriptors).some(d => !('value' in d) || !d.enumerable)) fail(code)
}
function checked(work, code) {
  try {return work()} catch (error) {if (error instanceof CryptoError) throw error; fail(code)}
}
function platform() {
  if (!globalThis.crypto?.subtle || typeof globalThis.crypto.getRandomValues !== 'function') fail('crypto_unavailable')
  return globalThis.crypto
}
function random(length) {return checked(() => platform().getRandomValues(new Uint8Array(length)), 'crypto_unavailable')}
function b64(value) {
  let binary = ''
  for (let offset = 0; offset < value.length; offset += 8192) binary += String.fromCharCode(...value.subarray(offset, offset + 8192))
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}
function unb64(value, {length, min = 0, max = length, code = 'invalid_envelope'} = {}) {
  if (typeof value !== 'string' || value.length > Math.ceil(max * 4 / 3) || !/^[A-Za-z0-9_-]*$/.test(value) || value.length % 4 === 1) fail(code)
  const output = checked(() => Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/')), char => char.charCodeAt(0)), code)
  if ((length !== undefined && output.length !== length) || output.length < min || output.length > max || b64(output) !== value) fail(code)
  return output
}
function scopeOf(raw, code = 'invalid_context') {return checked(() => validateScope(raw), code)}
function contextOf(raw) {
  exact(raw, ['appId', 'spaceId', 'collection', 'entityId', 'schemaVersion'], 'invalid_context')
  return checked(() => {
    const scope = validateScope({appId: raw.appId, spaceId: raw.spaceId})
    const item = validateBatch({protocolVersion: 1, operationId: 'crypto-context', mutations: [{type: 'put', collection: raw.collection, entityId: raw.entityId, schemaVersion: raw.schemaVersion, baseRevision: null, payload: null}]}).mutations[0]
    return {...scope, collection: item.collection, entityId: item.entityId, schemaVersion: item.schemaVersion}
  }, 'invalid_context')
}
function keyringOf(raw) {
  exact(raw, ['format', 'version', 'appId', 'spaceId', 'activeKeyId', 'keys'], 'invalid_keyring')
  if (raw.format !== 'tulai-keyring' || raw.version !== 1 || !Array.isArray(raw.keys) || raw.keys.length < 1 || raw.keys.length > 32) fail('invalid_keyring')
  return checked(() => {
    const scope = scopeOf({appId: raw.appId, spaceId: raw.spaceId}, 'invalid_keyring'), seen = new Set()
    const activeKeyId = validateId(raw.activeKeyId)
    const keys = raw.keys.map(key => {
      exact(key, ['id', 'key'], 'invalid_keyring')
      const id = validateId(key.id)
      if (seen.has(id)) fail('invalid_keyring')
      seen.add(id); unb64(key.key, {length: 32, code: 'invalid_keyring'})
      return {id, key: key.key}
    })
    if (!seen.has(activeKeyId)) fail('invalid_keyring')
    if (bytes(canonical(raw)).length > KEYRING_BYTES) fail('invalid_keyring')
    return {format: 'tulai-keyring', version: 1, ...scope, activeKeyId, keys}
  }, 'invalid_keyring')
}
function scopedKeyring(raw, context, decrypt = false) {
  const keyring = keyringOf(raw)
  if (keyring.appId !== context.appId || keyring.spaceId !== context.spaceId) fail(decrypt ? 'decryption_failed' : 'invalid_context')
  return keyring
}
function newKey() {return {id: 'k_' + b64(random(16)), key: b64(random(32))}}
export function createKeyring(rawScope) {
  const scope = scopeOf(rawScope), key = newKey()
  return {format: 'tulai-keyring', version: 1, ...scope, activeKeyId: key.id, keys: [key]}
}
export function rotateKeyring(raw) {
  const keyring = keyringOf(raw)
  if (keyring.keys.length >= 32) fail('payload_too_large')
  let key
  do {key = newKey()} while (keyring.keys.some(item => item.id === key.id))
  return {...keyring, activeKeyId: key.id, keys: [...keyring.keys, key]}
}
function passphraseBytes(value) {
  if (typeof value !== 'string' || !value.length || !value.isWellFormed()) fail('invalid_passphrase')
  const output = bytes(value)
  if (output.length > 1024) fail('invalid_passphrase')
  return output
}
async function importAes(raw) {
  try {return await platform().subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt'])} catch {fail('crypto_unavailable')}
}
async function derive(passphrase, salt) {
  try {
    const key = await platform().subtle.importKey('raw', passphrase, 'PBKDF2', false, ['deriveKey'])
    return await platform().subtle.deriveKey({name: 'PBKDF2', hash: 'SHA-256', iterations: ITERATIONS, salt}, key, {name: 'AES-GCM', length: 256}, false, ['encrypt', 'decrypt'])
  } catch {fail('crypto_unavailable')}
}
async function seal(plaintext, key, iv, aad) {
  try {return new Uint8Array(await platform().subtle.encrypt({name: 'AES-GCM', iv, additionalData: jsonBytes(aad), tagLength: 128}, key, plaintext))} catch {fail('crypto_unavailable')}
}
async function unseal(ciphertext, key, iv, aad) {
  try {return new Uint8Array(await platform().subtle.decrypt({name: 'AES-GCM', iv, additionalData: jsonBytes(aad), tagLength: 128}, key, ciphertext))} catch {fail('decryption_failed')}
}
function parse(plaintext) {return checked(() => JSON.parse(decoder.decode(plaintext)), 'invalid_envelope')}
function wrapAAD(envelope) {
  const {format, version, appId, spaceId, kdf, iterations, salt} = envelope
  return {domain: 'keyring', format, version, appId, spaceId, kdf, iterations, salt}
}
export async function wrapKeyring(raw, passphrase) {
  const keyring = keyringOf(raw), password = passphraseBytes(passphrase), salt = random(16), iv = random(12)
  const envelope = {format: 'tulai-keyring-wrapped', version: 1, appId: keyring.appId, spaceId: keyring.spaceId, kdf: 'PBKDF2-SHA256', iterations: ITERATIONS, salt: b64(salt), iv: b64(iv)}
  const key = await derive(password, salt)
  return {...envelope, ciphertext: b64(await seal(jsonBytes(keyring), key, iv, wrapAAD(envelope)))}
}
export async function unwrapKeyring(raw, passphrase, rawScope) {
  exact(raw, ['format', 'version', 'appId', 'spaceId', 'kdf', 'iterations', 'salt', 'iv', 'ciphertext'], 'invalid_envelope')
  if (raw.format !== 'tulai-keyring-wrapped' || raw.version !== 1 || raw.kdf !== 'PBKDF2-SHA256' || raw.iterations !== ITERATIONS) fail('invalid_envelope')
  const envelope = {...raw}, scope = scopeOf(rawScope), wrappedScope = scopeOf({appId: raw.appId, spaceId: raw.spaceId}, 'invalid_envelope')
  const salt = unb64(envelope.salt, {length: 16}), iv = unb64(envelope.iv, {length: 12}), ciphertext = unb64(envelope.ciphertext, {min: 16, max: KEYRING_BYTES + TAG_BYTES})
  const password = passphraseBytes(passphrase)
  if (scope.appId !== wrappedScope.appId || scope.spaceId !== wrappedScope.spaceId) fail('decryption_failed')
  const key = await derive(password, salt), keyring = keyringOf(parse(await unseal(ciphertext, key, iv, wrapAAD(envelope))))
  if (keyring.appId !== scope.appId || keyring.spaceId !== scope.spaceId) fail('decryption_failed')
  return keyring
}
function payloadOf(payload, context) {
  try {
    return validateBatch({protocolVersion: 1, operationId: 'crypto-payload', mutations: [{type: 'put', collection: context.collection, entityId: context.entityId, schemaVersion: context.schemaVersion, baseRevision: null, payload}]}).mutations[0].payload
  } catch (error) {fail(error.code === 'payload_too_large' ? 'payload_too_large' : 'invalid_payload')}
}
function envelopeOf(raw) {
  exact(raw, ['format', 'version', 'keyId', 'iv', 'ciphertext'], 'invalid_envelope')
  if (raw.format !== 'tulai-encrypted' || raw.version !== 1) fail('invalid_envelope')
  const keyId = checked(() => validateId(raw.keyId), 'invalid_envelope')
  const iv = unb64(raw.iv, {length: 12}), ciphertext = unb64(raw.ciphertext, {min: TAG_BYTES, max: LIMITS.payloadBytes})
  if (jsonBytes(raw).length > LIMITS.payloadBytes) fail('payload_too_large')
  return {keyId, iv, ciphertext}
}
async function encryptValue(payload, keyring, context, domain) {
  const keyId = keyring.activeKeyId, raw = keyring.keys.find(item => item.id === keyId), iv = random(12)
  const plaintext = jsonBytes(payload), key = await importAes(unb64(raw.key, {length: 32, code: 'invalid_keyring'}))
  const ciphertext = await seal(plaintext, key, iv, {domain, version: 1, ...context, keyId})
  const envelope = {format: 'tulai-encrypted', version: 1, keyId, iv: b64(iv), ciphertext: b64(ciphertext)}
  if (jsonBytes(envelope).length > LIMITS.payloadBytes) fail('payload_too_large')
  return envelope
}
async function decryptValue(raw, keyring, context, domain) {
  const {keyId, iv, ciphertext} = envelopeOf(raw), material = keyring.keys.find(item => item.id === keyId)
  if (!material) fail('unknown_key')
  const key = await importAes(unb64(material.key, {length: 32, code: 'invalid_keyring'}))
  return parse(await unseal(ciphertext, key, iv, {domain, version: 1, ...context, keyId}))
}
export async function encryptRecord(payload, rawKeyring, rawContext) {
  const context = contextOf(rawContext), keyring = scopedKeyring(rawKeyring, context), value = payloadOf(payload, context)
  return encryptValue(value, keyring, context, 'record')
}
export async function decryptRecord(envelope, rawKeyring, rawContext) {
  const context = contextOf(rawContext), keyring = scopedKeyring(rawKeyring, context, true)
  return payloadOf(await decryptValue(envelope, keyring, context, 'record'), context)
}

function cancelled(signal) {if (signal?.aborted) throw new DOMException('操作已取消。', 'AbortError')}
function sourceOf(source, max) {
  return checked(() => {
    const blob = typeof Blob !== 'undefined' && source instanceof Blob
    const byteLength = blob ? source.size : source?.byteLength
    if (!Number.isSafeInteger(byteLength) || byteLength < 0 || (!blob && typeof source?.read !== 'function')) fail('invalid_source')
    if (byteLength > max) fail('payload_too_large')
    return {byteLength, read: blob ? async (offset, length) => new Uint8Array(await source.slice(offset, offset + length).arrayBuffer()) : source.read.bind(source)}
  }, 'invalid_source')
}
function sinkOf(sink) {
  return checked(() => {
    if (!sink || ['write', 'commit', 'abort'].some(name => typeof sink[name] !== 'function')) fail('invalid_sink')
    return {write: sink.write.bind(sink), commit: sink.commit.bind(sink), abort: sink.abort.bind(sink)}
  }, 'invalid_sink')
}
async function cancellableRead(source, offset, length, signal) {
  cancelled(signal)
  // 读取无发布副作用，可以在取消时停止等待；race 仍观察晚到的拒绝。
  const reading = Promise.resolve().then(() => {cancelled(signal); return source.read(offset, length)})
  if (!signal) return reading
  let onAbort
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(new DOMException('操作已取消。', 'AbortError'))
    signal.addEventListener('abort', onAbort, {once: true})
    if (signal.aborted) onAbort()
  })
  try {return await Promise.race([reading, aborted])}
  finally {signal.removeEventListener('abort', onAbort)}
}
async function readPart(source, offset, length, signal) {
  cancelled(signal)
  let value
  try {value = await cancellableRead(source, offset, length, signal)} catch {cancelled(signal); fail('source_failed')}
  cancelled(signal)
  if (!(value instanceof Uint8Array) || value.byteLength !== length) fail('integrity_mismatch')
  return new Uint8Array(value)
}
async function writePart(sink, offset, value, signal) {
  cancelled(signal)
  try {await sink.write(offset, value)} catch {cancelled(signal); fail('sink_failed')}
  cancelled(signal)
}
async function commitSink(sink, signal) {
  cancelled(signal)
  // 发布本身由调用者保证原子性；成功提交后不再把稍后的取消误报成未发布。
  try {await sink.commit()} catch {fail('sink_failed')}
}
function chunkIV(prefix, index) {
  const iv = new Uint8Array(12); iv.set(prefix); new DataView(iv.buffer).setUint32(8, index, false); return iv
}
const countOf = length => Math.max(1, Math.ceil(length / PLAIN_CHUNK))
const partLength = (length, index) => Math.min(PLAIN_CHUNK, Math.max(0, length - index * PLAIN_CHUNK))
const chunkAAD = (context, index, plaintextBytes) => ({domain: 'object-chunk', version: 1, ...context, index, plaintextBytes})
function manifestOf(raw) {
  exact(raw, ['objectKey', 'noncePrefix', 'plaintextBytes', 'plaintextSha256', 'ciphertextSha256', 'ciphertextBytes', 'chunkCount'], 'invalid_envelope')
  const manifest = {...raw}
  unb64(manifest.objectKey, {length: 32}); unb64(manifest.noncePrefix, {length: 8})
  checked(() => {validateObjectHash(manifest.plaintextSha256); validateObjectHash(manifest.ciphertextSha256)}, 'invalid_envelope')
  if (!Number.isSafeInteger(manifest.plaintextBytes) || manifest.plaintextBytes < 0 || manifest.plaintextBytes > MAX_PLAIN || manifest.chunkCount !== countOf(manifest.plaintextBytes) || manifest.ciphertextBytes !== manifest.plaintextBytes + manifest.chunkCount * TAG_BYTES) fail('invalid_envelope')
  return manifest
}

export async function encryptObject(rawSource, rawSink, options) {
  const sink = sinkOf(rawSink)
  try {
    const {keyring: rawKeyring, context: rawContext, signal} = options ?? {}
    cancelled(signal)
    const context = contextOf(rawContext), keyring = scopedKeyring(rawKeyring, context), source = sourceOf(rawSource, MAX_PLAIN)
    const objectKey = random(32), prefix = random(8), key = await importAes(objectKey), count = countOf(source.byteLength)
    const plaintextHash = sha256.create(), ciphertextHash = sha256.create()
    let offset = 0
    for (let index = 0; index < count; index++) {
      const plaintext = await readPart(source, index * PLAIN_CHUNK, partLength(source.byteLength, index), signal)
      plaintextHash.update(plaintext)
      const ciphertext = await seal(plaintext, key, chunkIV(prefix, index), chunkAAD(context, index, source.byteLength))
      cancelled(signal); ciphertextHash.update(ciphertext)
      await writePart(sink, offset, ciphertext, signal); offset += ciphertext.length
    }
    const descriptor = {sha256: hex(ciphertextHash.digest()), byteLength: offset}
    const manifest = await encryptValue({objectKey: b64(objectKey), noncePrefix: b64(prefix), plaintextBytes: source.byteLength, plaintextSha256: hex(plaintextHash.digest()), ciphertextSha256: descriptor.sha256, ciphertextBytes: offset, chunkCount: count}, keyring, context, 'object-manifest')
    await commitSink(sink, signal)
    return {descriptor, manifest}
  } catch (error) {
    try {await sink.abort(error)} catch { /* 原失败不被清理失败取代。 */ }
    throw error
  }
}

export async function decryptObject(rawSource, prepared, rawSink, options) {
  const sink = sinkOf(rawSink)
  try {
    const {keyring: rawKeyring, context: rawContext, signal} = options ?? {}
    cancelled(signal)
    const context = contextOf(rawContext), keyring = scopedKeyring(rawKeyring, context, true)
    exact(prepared, ['descriptor', 'manifest'], 'invalid_envelope')
    const descriptor = checked(() => validateObjectDescriptor(prepared.descriptor), 'invalid_envelope')
    const manifest = manifestOf(await decryptValue(prepared.manifest, keyring, context, 'object-manifest'))
    if (manifest.ciphertextSha256 !== descriptor.sha256 || manifest.ciphertextBytes !== descriptor.byteLength) fail('decryption_failed')
    const source = sourceOf(rawSource, OBJECT_LIMITS.objectBytes)
    if (source.byteLength !== descriptor.byteLength) fail('integrity_mismatch')
    const key = await importAes(unb64(manifest.objectKey, {length: 32})), prefix = unb64(manifest.noncePrefix, {length: 8})
    const plaintextHash = sha256.create(), ciphertextHash = sha256.create()
    let offset = 0
    for (let index = 0; index < manifest.chunkCount; index++) {
      const length = partLength(manifest.plaintextBytes, index)
      const ciphertext = await readPart(source, index * OBJECT_LIMITS.chunkBytes, length + TAG_BYTES, signal)
      ciphertextHash.update(ciphertext)
      const plaintext = await unseal(ciphertext, key, chunkIV(prefix, index), chunkAAD(context, index, manifest.plaintextBytes))
      cancelled(signal)
      if (plaintext.length !== length) fail('integrity_mismatch')
      plaintextHash.update(plaintext)
      await writePart(sink, offset, plaintext, signal); offset += plaintext.length
    }
    const sha = hex(plaintextHash.digest())
    if (offset !== manifest.plaintextBytes || sha !== manifest.plaintextSha256 || hex(ciphertextHash.digest()) !== descriptor.sha256) fail('integrity_mismatch')
    await commitSink(sink, signal)
    return {byteLength: offset, sha256: sha}
  } catch (error) {
    try {await sink.abort(error)} catch { /* 保留认证或读取失败。 */ }
    throw error
  }
}
