# 通用客户端 SDK 0.1.0

当前提供源码与本地打包验收，尚未发布npm。包名`@tulai-design/sync-sdk`，ESM；入口`@tulai-design/sync-sdk`为传输，`@tulai-design/sync-sdk/crypto`为客户端加密。服务wire v1、客户端加密格式v1、SDK版本0.1.0分别管理。Node24.11与现代安全上下文浏览器；浏览器通常由Vite等打包器解析依赖，也已通过import map原生模块互通验收。唯一运行时依赖是精确`@noble/hashes@2.4.0`（增量SHA256），AES/PBKDF2使用原生WebCrypto。

## 职责与前提

SDK负责HTTP校验、操作查询、有限重试、分页、对象传输和独立加密工具。业务数据、outbox、冲突界面、临时对象仓、密文和cursor的持久化仍由产品实现。搭搭尚未接入，现有整包快照同步不是此SDK的增量适配器；默默也尚未产品接入。

```ts
import {createSyncClient} from '@tulai-design/sync-sdk'

const client = createSyncClient({
  baseUrl: 'https://sync.example.test',
  token: deviceToken,
  appId: 'dada',
  spaceId: 'personal',
})
```

生产URL要求https；本机开发允许http的localhost、127.0.0.1、[::1]。允许部署前缀，禁止userinfo/query/hash。请求不跟随重定向，不发送浏览器cookie、不缓存。跨域部署目前需要后续CORS设计；本轮浏览器验收为同源。SDK不自动读取系统配置、浏览器存储或用户密钥。

## 提交与恢复

```ts
// finalBatch 包含稳定 operationId 和最终密文；首次网络发送前已持久化。
const result = await client.commit(finalBatch, {signal})
if (result.status === 'conflict') {
  // 保留本地候选，让用户或明确业务策略解决；不自动覆盖。
}
const known = await client.operation(finalBatch.operationId, {signal})
```

`commit`在第一次await前验证并复制整个请求。同一调用的重试始终发送相同字节；跨调用/重启重试也必须传回已持久化的同一份密文batch。**相同operation不能重新随机加密、修改payload或改变baseRevision。** 冲突返回正常`ConflictReceipt`，其他失败抛`SyncClientError`。只有规范的404 not_found让operation/object查询返回undefined，非法响应、网络断开、未知协议不会变成空库。

错误包含code/status/retryable/mayHaveCommitted。超时、断线或响应损坏时写入可能已确认，应查原operation或upload身份。取消的错误name为AbortError，已有不确定写入仍带mayHaveCommitted；取消不会撤回服务已保存的数据。服务重启/恢复后先检查cursor和原操作状态，不直接清空本地待同步内容。

默认每次请求15秒、最多额外重试2次，retries允许0–3；100/200/400ms有界退避。仅幂等方法的网络/超时及408/429/502/503/504可重试；创建上传与签发配对码不自动重试，避免丢响应重复分配资源。401/403、冲突和输入错误不靠重试解决。自定义fetchImpl用于平台适配/测试，必须遵守fetch和AbortSignal语义。

## 分页与入站事务

```ts
for await (const page of client.pages({cursor: lastAppliedCursor, limit: 10, signal})) {
  // 这里由产品在一个本地事务内：检查未发修改/版本，应用整页，再保存page.cursor。
  await applyPageTransaction(page)
}
```

pages只遍历一次固定水位，读完即结束；不是后台监听器。SDK不预取下一页，调用方当前事务失败可退出循环，之后从已确认cursor继续。每页保持完整commit；响应校验包括字段、预算、revision顺序、记录一致性及非空cursor，跨页检测重复cursor和revision跳跃。删除标记由业务按版本处理，缺对象/解密失败不能当作删除。

## 对象与暂存

`ByteSource`为Blob，或`{byteLength,read(offset,length):Promise<Uint8Array>}`。整个操作期间必须是不可变快照。上传会先逐块计算完整hash，再创建上传和补传缺块；每次读取最多1MiB。首次创建后await onCheckpoint持久化成功才发送任何块：

```ts
const descriptor = await client.uploadObject(immutableCiphertext, {
  checkpoint: savedCheckpoint,
  onCheckpoint: saveCheckpoint,
  signal,
})
```

checkpoint绑定app/space、密文hash/长度与uploadId，不含令牌。过期或已清理上传会重新创建并保存新checkpoint；同内容已完整存在则直接确认。创建响应丢失无法知道新uploadId，调用方可重新创建，但会消耗服务临时上传额度直到完成或过期。

下载使用`TransactionalSink`：`write(offset,bytes)`只暂存，`commit()`原子发布，`abort(error)`清理。SDK验证metadata、每块与完整对象hash后才commit；失败调用abort。外部write不可取消时等待它结束再清理，防止迟到写入越过abort。commit是发布边界，成功后迟到取消不能改报失败；sink.commit自身必须保证失败不发布或可恢复，SDK无法替代产品事务。

```ts
await client.downloadObject(descriptor, temporarySink, {signal})
```

单对象wire<=256MiB，块<=1MiB；加密明文预算扣除认证tag，详见[加密格式](encryption.md)。响应按实际流读取计数：changes<=8MiB、其他JSON<=1MiB、binary<=1MiB，超限提前取消，不只相信Content-Length。原始分块、元数据、完成上传接口也公开，见类型声明。

## 设备管理

管理员调用pair签发限定scope/期限凭证；新设备自行生成随机token后调用redeem，同码同token可安全重试；devices/revoke用于列表与撤销。访问令牌与加密口令/space keys分离，撤销不能追回设备已经保存的密钥和明文。具体服务权限、静态身份保留及TTL以[HTTP协议](protocol.md)为准。

## 检查与打包

- `pnpm check`：模块语法。
- `pnpm check:types`：公开SDK/crypto类型消费，严格NodeNext。
- `pnpm test`：既有服务、SDK、真实加密及两类合成投影。
- `pnpm pack --pack-destination /tmp/指定目录`：仅本地产物，尚未发布；files只包含client/protocol与相关文档，不包含服务、测试库或凭据。
- `node scripts/client-browser-qa.mjs`：仅loopback合成验收页面；验证Node/浏览器双向密文、真实HTTP和多块对象。结束后停止进程，不作为生产服务。
