# 客户端加密格式 v1

当前SDK实现，尚未接入产品设置或钥匙管理界面。wire协议v1仍只保存opaque JSON与对象；服务不持有解密口令、不执行或强制加密，因此capabilities.encryption仍为false。使用本模块的客户端可以在发送前加密。未使用本模块的普通记录仍可明文保存，不能从服务能力标记推断整个空间已加密。

## 密钥与封装

每个appId/spaceId使用随机32字节AES-256空间数据key，keyring最多32把、每把有随机keyId，activeKeyId用于新写。明文keyring包含format=tulai-keyring、version=1、scope、activeKeyId与keys；仅留在内存或受控备份，禁止放入普通payload、日志或模型上下文。

口令使用原样UTF8，不trim或normalize，拒绝空字符串、孤立代理项与超过1024字节。PBKDF2-HMAC-SHA256固定600000次、随机16字节salt派生AES256包装key，AES-GCM使用12字节随机IV和128bit tag。wrapKeyring返回：

```text
{format:"tulai-keyring-wrapped", version:1, appId, spaceId,
 kdf:"PBKDF2-SHA256", iterations:600000, salt, iv, ciphertext}
```

二进制字段严格无填充base64url。AAD为canonical JSON `{domain:"keyring",format,version,appId,spaceId,kdf,iterations,salt}`的UTF8。解包先验证闭集/版本/固定参数/字节预算再派生，不接受远端任意iterations。错误口令或认证失败统一decryption_failed，未知格式invalid_envelope；访问token不参与派生。

该算法参数依据与原生互通研究见[研究记录](../.trellis/tasks/10-28-client-protocol/research/client-crypto.md)。实现组合不等于完成外部密码协议安全审计；浏览器与Node的基本互通已测试，移动端低性能设备的600k派生延迟尚未实测。

## 记录

`encryptRecord(payload,keyring,context)` / `decryptRecord(envelope,keyring,context)`，context固定为`{appId,spaceId,collection,entityId,schemaVersion}`。AES256-GCM随机12B IV、128bit tag，输出：

```text
{format:"tulai-encrypted",version:1,keyId,iv,ciphertext}
```

AAD为canonical `{domain:"record",version:1,...context,keyId}`，scope和实体上下文来自调用方预期记录，不能只信任远端自报身份。服务器事后revision不绑定。密文base64、IV/keyId等计入128KiB payload预算，超过时调用方使用对象；不承诺128KiB明文都可内联。

首次发送前持久化最终密文batch和operationId，重试不重新加密。原操作候选同样是可解密的密文。objectRefs是可见外壳，客户端须与解密后的manifest descriptor精确对照，不能直接信任外壳将其当正文；decryptObject本身核对prepared.descriptor与认证manifest。

## 大对象

每次准备对象独立生成随机32B object key、8B nonce prefix，只用于本次不可变内容。明文块1048560字节，GCM附加16Btag后正好是1MiB wire块；IV=prefix8+uint32BE(index)。AAD为canonical `{domain:"object-chunk",version:1,...context,index,plaintextBytes}`。最多256块，明文上限268431360字节；空对象也产生一个16字节认证块。

`encryptObject(source,sink,{keyring,context,signal})`逐块加密和hash，暂存全部密文，返回前sink.commit。只有准备完成后才有整个密文摘要，之后调用SDK上传准备好的immutable source。中断重新准备会生成新key/nonce；续传必须复用已有prepared密文，不开放用同objectkey重新加密已修改内容的接口。

返回`{descriptor:{sha256,byteLength},manifest:<加密信封>}`。manifest明文为：

```text
{objectKey,noncePrefix,plaintextBytes,
 plaintextSha256,ciphertextSha256,ciphertextBytes,chunkCount}
```

manifest字段严格闭集，版本由外层加密信封和AAD承载；manifest使用空间key再次AES-GCM加密，信封同记录，但AAD domain为object-manifest，防止与普通record混用。objectKey不出现在外部objectRefs，只有密文hash/长度公开。产品把prepared对象放进记录的加密payload，objectRefs指向对应密文descriptor。

`decryptObject(source,prepared,sink,options)`先解密manifest、核对descriptor与预算，再逐块认证和检查明/密文双hash，最后commit明文暂存；失败abort，不能发布部分或篡改内容。source/sink及取消语义同[SDK](client.md)。

## 改口令与轮换

改口令：旧口令unwrap，再用新口令wrap同一keyring；不重写全部记录。轮换数据key：rotateKeyring生成新active key并保留旧keys，旧历史/冲突/未提交操作仍可读取。满32把时拒绝继续加key，不自动删除旧key；真正全量重加密与安全GC待后续。

产品用稳定operation对keyring普通记录做CAS更新，先保存新包装候选，再提交；确认成功后才切换新写key。网络结果不明查询原operation并复发原包装，不能重复wrap同operation。并发轮换冲突保留双方候选，不自动覆盖丢key。当前集成测试模拟该流程，产品持久事务尚未实现。

服务鉴权与加密权限不同：撤销设备不能让它忘掉已下载明文/key；旧口令持有者若留有旧包装仍能读取当时key。改口令和追加新key不宣称追回旧数据访问权。遗失所有口令/keyring时服务无法解密，恢复材料需由产品明确备份。

## 可见信息与边界

服务仍能看到应用/空间/集合/实体标识、schema/revision、操作来源、删除标记、对象摘要/长度和流量。当前格式保护payload和对象内容完整性与机密性，不实现隐藏元数据、签名设备身份、恶意服务历史防回滚/新鲜度证明。TLS、可信客户端代码和本机密钥保护仍是部署与产品职责。
